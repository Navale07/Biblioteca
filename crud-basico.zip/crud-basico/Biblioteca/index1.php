<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style1.css">
</head>

<body>

    <header class="header">
        <div class="menu container">
            <a href="#" class="logo">Bienvenido Administrar Biblioteca</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="Imagenes/menu.png" class="menu-icono" alt="">

            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="file:///C:/Users/57319/OneDrive/Escritorio/pagina/index.html">Inicio</a></li>                    
                    <li><a href="index.php">Autor</a></li>
                    <li><a href="index2.php">Libro</a></li>
                    <li><a href="https://wa.me/573193677141?text=Somos%20A.L.G%20SOLUCIONES%20y%20para%20nosotros%20es%20un%20verdadero%20gusto%20atenderte%20el%20d%C3%ADa%20de%20hoy,%20en%20un%20momento%20estaremos%20resolviendo%20todas%20tus%20dudas%20e%20inquietudes.">Contacto</a></li>
                </ul>
            </nav>
        </div>
        <div class="header-content container">

            <div class="header-txt">
                <h1>BIBLIOTECA VIRTUAL </h1>
                <p>
                    Es un beneficio para los miembros de la comunidad universitaria,Ya que permite elevar la
                    calidad de trabajo que opera en toda Colombia. <br> Accesibilidad, permite consultar la información a cualquier hora, desde cualquier lugar y desde cualquier dispositivo. 
                    Sin duda, las bibliotecas virtuales son un elemento clave 
                    en la transición definitiva de la educación
                    presencial a la enseñanza remota o híbrida.
                    Asesoría Especializada;
                    Servicio Vizualizacion de Autores y Libros.
                </p>
                <a href= "https://youtu.be/JGMA4AwRmnQ?si=8yjKF1hw0j5Of2gT"  class="btn-1"> Informacion</a>
            </div>
        </div>
    </header>

    <section class="about">

        <div class="about-content container">

            <div class="about-1">
                <h3>Ventajas Bibliotecas en Linea</h3>
                <p>Una de las ventajas más importantes de las bibliotecas virtuales es que te dan acceso a múltiples contenidos con un número potencialmente infinito de recursos disponibles.
                Por contrapartida, la principal limitación que tienen las bibliotecas tradicionales es representada por el espacio físico: los libros consumen mucho espacio. Además, 
                la gente tiene que transportarse para buscar un material en particular. Ni hablar de los estados de conservación de los materiales y la posible pérdida de los mismos.<br><br>
                Al usar una biblioteca digital, los lectores pueden acceder a una gran cantidad de información en un solo lugar, ya sea a través de una computadora o un dispositivo móvil.

                    Gracias a Internet y al almacenamiento en la nube, las bibliotecas digitales superan esta limitación y amplían los horizontes de aprendizaje de los estudiantes, 
                    ya que pueden acceder a mayores conocimientos y compartir contenidos con otros, facilitando la expansión de la educación. <br><br>
                                        
                </p>
                <br>
                <p>
                Para un mejor entendimiento sobre qué es una biblioteca virtual, es importante conocer sus ventajas y beneficios que aporta al desarrollo de la ciencia, más allá del uso personal que podamos darle.
                Las bibliotecas en línea ayudan a la sociedad científica, ya que actúan como un depósito para el almacenamiento de importantes datos, información y hallazgos de investigación.
                Durante mucho tiempo, los registros físicos de estudios e investigaciones científicas tuvieron que convivir con un tema crítico: se destruyeron o se perdieron.
                Hoy, gracias a las bibliotecas digitales, las copias en línea de estudios e investigaciones pueden protegerse y recopilarse para crear un patrimonio virtual de información para las generaciones futuras.<br><br>

                Siempre que tengas acceso a una conexión a Internet, una biblioteca virtual es accesible en cualquier lugar y en cualquier momento mediante un dispositivo tecnológico simple, como una PC, una tableta o incluso un teléfono inteligente.
                Esto significa que los estudiantes pueden consultar libros, imágenes, videos en línea y todos los demás contenidos educativos sin tener que esperar y dirigirse a la biblioteca física más cercana.
                Es una ventaja que no ofrecen las bibliotecas tradicionales. Puedes ingresar a una biblioteca virtual en un entorno formal, por ejemplo, en la escuela o la universidad, o puedes relajarte en tu casa y tener acceso instantáneo a la información que necesitas.
                Además, el tema del acceso a la información de las bibliotecas virtuales significa una mayor diversificación de formatos y maneras de comunicar. Debido a la naturaleza multimedia de lo digital, ahora no sólo sirven como fuente de información textos, sino también videos y hasta podcasts.

                    
                </p>
                <a href="https://www.comunidadbaratz.com/blog/los-25-servicios-digitales-que-se-ofrecen-desde-las-bibliotecas/" class="btn-1">Saber mas</a>
            </div>
            <div class="about-2">
                <h3>Algunos Libros</h3>
                <div class="about-img">
                    <img src="Imagenes/chica.webp" alt="">
                    <div class="about-txt">
                        <h4>LA CHICA DEL TREN</h4>                        
                        <p>Paula Hawkins </p>
                    </div>
                </div>
                <div class="about-img">
                    <img src="Imagenes/psi.webp" alt="">
                    <div class="about-txt">
                        <h4>EL PSICOANALISTA</h4>
                        <p>John Katzenbach</p>                        
                    </div>
                </div>
                <div class="about-img">
                    <img src="Imagenes/ma.jpg" alt="">
                    <div class="about-txt">
                        <h4>UNA ESCALERA AL CIELO</h4>
                        <p>Mario Mendoza</p>                        
                    </div>
                </div>
                <div class="about-img">
                    <img src="Imagenes/juji.jpg" alt="">
                    <div class="about-txt">
                        <h4>EL CORONEL NO TIENE QUIEN LE ESCRIBA</h4>
                        <p>Gabriel Garcia Marquez</p>                        
                    </div>
                </div>
                <div class="about-img">
                    <img src="Imagenes/es.jpg" alt="">
                    <div class="about-txt">
                        <h4>EL ALQUIMISTA</h4>
                        <p>Paulo Coelho</p>                        
                    </div>
                </div>
                <div class="about-img">
                    <img src="Imagenes/sa.jpg" alt="">
                    <div class="about-txt">
                        <h4>SATANAS</h4>
                        <p>Mario Mendoza</p>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <main class="services">
        <div class="services-txt container">
            <h2>Selección de servicio</h2>
            <p>
            El almacenamiento digital de libros y, sobre todo, de audios, solucionan el problema del deterioro.
            En las bibliotecas tradicionales, las cintas de audio y los discos de vinilo se compartían entre muchos estudiantes, lo que planteaba el problema de soportar una gran cantidad de reproducciones.
            Las fotografías frágiles o los documentos antiguos debían resistir varios traspasos y consultas, corriendo el riesgo de sufrir roturas u otros daños.
            Gracias a la digitalización de materiales, es posible acceder a contenidos cuantas veces lo necesites, utilizando formatos (mp3, imágenes digitales, libros de texto online, etc.)
            que definitivamente son mucho más seguros de utilizar sin correr el riesgo de deteriorarse.
                
            </p>
        </div>
        <div class="services-content container">

            <img src="Imagenes/libro.jpg" alt="">
            <img src="Imagenes/pr2.jpg" alt="">
            <img src="Imagenes/pr4.jpg" alt="">
            <img src="Imagenes/lectura.jpg" alt="">
            
         
            
        </div>
    </main>

    <footer class="footer container">
        <h2>Contactanos</h2>
        <form action="https://formsubmit.co/valencc643@gmail.com " method="POST" >
            <div class="form-group">
                <div>
                    <input type="text" placeholder="Nombre" name="name" class="campo">
                    <input type="email" placeholder="email" name="email" class="campo">
                    <br>
                    <input type="TEXT" pattern="[0-9]{1,70}" placeholder="telefono" name="telefono" class="campo">
                    <input type="text" placeholder="Direccion" name="Direccion" class="campo">                    
                   
                </div>
                <textarea name="message" cols="30" rows="2" placeholder="Mensaje" class="campo"></textarea>
            </div>
            <input type="submit" value="Enviar" class="btn-1">

            <input type="hidden" name="_next" value="http://127.0.0.1:5500/index.html">
            <input type="hidden" name="_captcha" value="false">
        </form>
    </footer>
</body>

</html>