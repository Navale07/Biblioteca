<?php

include("connection.php");
$con = connection();

$id=$_POST["Id"];
$name = $_POST['name'];
$lastname = $_POST['lastname'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$ciudad = $_POST['ciudad'];



$sql="UPDATE usuarios SET name='$name', lastname='$lastname', direccion='$direccion', telefono='$telefono', email='$email', ciudad='$ciudad' WHERE Id='$id'";
$query = mysqli_query($con, $sql);

if($query){
    Header("Location: index.php");
}else{

}

?>