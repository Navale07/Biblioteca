<?php
include("connection.php");
$con = connection();

$id = null;
$name= $_POST['name'];
$genero = $_POST['genero'];



$sql = "INSERT INTO libros VALUES('$id','$name','$genero')";
$query = mysqli_query($con, $sql);

if($query){
    Header("Location: index2.php");
}else{

}

?>