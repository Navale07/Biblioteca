<?php

    $servername = "localhost:3307";
    $username = "root";
    $password = "";
    $dbname = "empleados";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
        die("Conexión fallida: " . mysqli_connect_error());
    }
  
    $salarioMinimo = 500; 

    $sql = "SELECT COUNT(*) AS total_empleados FROM usuarios WHERE sueldo > $salarioMinimo";
    
    $resultado = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($resultado) > 0) {
    
        $fila = mysqli_fetch_assoc($resultado);
        $totalEmpleados = $fila["total_empleados"];
    
        echo "Total de empleados que ganan más del salario mínimo: " . $totalEmpleados;
    } else {
    echo "No se encontraron registros";
}
    
    $conn->close();
    


?>