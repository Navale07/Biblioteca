<?php
include("connection.php");
$con = connection();

$id = null;
$name = $_POST['name'];
$lastname = $_POST['lastname'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$ciudad= $_POST['ciudad'];


$sql = "INSERT INTO usuarios VALUES('$id','$name','$lastname','$direccion','$telefono','$email','$ciudad')";
$query = mysqli_query($con, $sql);

if($query){
    Header("Location: index.php");
}else{

}

?>