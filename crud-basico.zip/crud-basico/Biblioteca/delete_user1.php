<?php

include("connection.php");
$con = connection();

$id=$_GET["id"];

$sql="DELETE FROM libros WHERE id='$id'";
$query = mysqli_query($con, $sql);

if($query){
    Header("Location: index2.php");
}else{

}

?>