<?php 
    include("connection.php");
    $con= connection();

    $id=$_GET['id'];

    $sql="SELECT * FROM libros WHERE Id='$id'";
    $query=mysqli_query($con, $sql);

    $row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="libro.css" rel="stylesheet">
        <h2>ACTUALIZAR DATOS LIBRO</h2>
        
    </head>
    <body>
        <div class="empleados-form">
            <form action="edit_user1.php" method="POST">
                <input type="hidden" name="id" value="<?= $row['id']?>">
                <input type="text" name="name" placeholder="Nombre" value="<?= $row['nombre']?>">
                <input type="text" name="genero" placeholder="Genero" value="<?= $row['genero']?>">         
                

                <input type="submit" value="Actualizar">
            </form>
        </div>
    </body>
</html>