<?php 
    include("connection.php");
    $con= connection();

    $id=$_GET['Id'];

    $sql="SELECT * FROM usuarios WHERE Id='$id'";
    $query=mysqli_query($con, $sql);

    $row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="style.css" rel="stylesheet">
        <h2>ACTUALIZAR DATOS AUTOR</h2>
        
    </head>
    <body>
        <div class="empleados-form">
            <form action="edit_user.php" method="POST">
                <input type="hidden" name="Id" value="<?= $row['Id']?>">
                <input type="text" name="name" placeholder="Nombre" value="<?= $row['name']?>">
                <input type="text" name="lastname" placeholder="Apellidos" value="<?= $row['lastname']?>">
                <input type="text" name="direccion" placeholder="Direccion" value="<?= $row['direccion']?>">
                <input type="text" name="telefono" placeholder="Telefono" value="<?= $row['telefono']?>">
                <input type="text" name="email" placeholder="Email" value="<?= $row['email']?>">
                <input type="text" name="ciudad" placeholder="Ciudad" value="<?= $row['ciudad']?>">
                

                <input type="submit" value="Actualizar">
            </form>
        </div>
    </body>
</html>